package org.BedWars;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.entity.Player;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.concurrent.atomic.AtomicBoolean;

public class AutoUpdater {

    private final BedWarsPlugin plugin;
    private final String repoOwner;
    private final String repoName;
    private final String githubToken; // token z config.yml
    private final File versionFile;
    private final boolean DEBUG = true;

    private volatile String lastDownloadedJarName = null;
    private volatile String lastDownloadedVersion = null;
    private final AtomicBoolean downloadInProgress = new AtomicBoolean(false);
    // AutoUpdater.java — dodaj getter
    public String getLastDownloadedJarName() {
        return this.lastDownloadedJarName;
    }

    public String getLastDownloadedVersion() {
        return this.lastDownloadedVersion;
    }
    private void debug(String msg) {
        if (DEBUG) plugin.getLogger().info("[DEBUG] " + msg);
    }

    public AutoUpdater(BedWarsPlugin plugin, String repoOwner, String repoName, String githubToken) {
        this.plugin = plugin;
        this.repoOwner = repoOwner;
        this.repoName = repoName;
        this.githubToken = githubToken;
        this.versionFile = new File(plugin.getDataFolder(), "version.txt");

        if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
        if (!versionFile.exists()) {
            try (FileWriter writer = new FileWriter(versionFile)) {
                writer.write(plugin.getDescription().getVersion());
            } catch (IOException e) {
                plugin.getLogger().warning("Nie udało się utworzyć pliku version.txt: " + e.getMessage());
            }
        }
    }

    /** Uruchom okresowe sprawdzanie co 10 sekund (200 ticków). */
    public void startPeriodicCheck() {
        checkAndUpdate(); // od razu sprawdź
        Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, this::checkAndUpdate, 200L, 200L);
    }

    public void checkAndUpdate() {
        debug("Rozpoczynam sprawdzanie aktualizacji...");

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                debug("Łączenie z GitHub API...");
                URL url = new URL("https://api.github.com/repos/" + repoOwner + "/" + repoName + "/releases/latest");
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestProperty("User-Agent", "Mozilla/5.0");
                connection.setRequestProperty("Accept", "application/vnd.github.v3+json");
                if (githubToken != null && !githubToken.isEmpty()) {
                    connection.setRequestProperty("Authorization", "token " + githubToken);
                }
                connection.connect();

                int responseCode = connection.getResponseCode();
                debug("Kod odpowiedzi GitHub: " + responseCode);
                if (responseCode != 200) {
                    plugin.getLogger().warning("GitHub API ERROR: " + responseCode);
                    return;
                }

                JsonObject json = JsonParser.parseReader(
                        new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8)
                ).getAsJsonObject();

                String latestVersion = json.get("tag_name").getAsString();
                debug("Najnowsza wersja na GitHub: " + latestVersion);

                JsonArray assets = json.getAsJsonArray("assets");
                if (assets.size() == 0) {
                    plugin.getLogger().warning("Brak plików w release!");
                    return;
                }

                String downloadUrl = null;
                String jarName = null;
                for (int i = 0; i < assets.size(); i++) {
                    JsonObject asset = assets.get(i).getAsJsonObject();
                    String name = asset.get("name").getAsString();
                    if (name.endsWith(".jar")) {
                        downloadUrl = asset.get("browser_download_url").getAsString();
                        jarName = name;
                        break;
                    }
                }

                if (downloadUrl == null) {
                    plugin.getLogger().warning("Nie znaleziono pliku JAR!");
                    return;
                }

                String localVersion = readLocalVersion();
                debug("Wersja lokalna: " + localVersion);

                if (!latestVersion.equals(localVersion)) {
                    debug("WYKRYTO NOWĄ WERSJĘ! -> " + latestVersion);

                    lastDownloadedJarName = jarName;
                    lastDownloadedVersion = latestVersion;

                    if (downloadToTemp(downloadUrl, jarName)) {
                        applyUpdateWithPlugman();
                    } else {
                        plugin.getLogger().warning("Nie udało się pobrać aktualizacji.");
                    }
                } else {
                    debug("Brak aktualizacji.");
                }

            } catch (Exception e) {
                plugin.getLogger().warning("Błąd checkAndUpdate(): " + e.getMessage());
            }
        });
    }

    private boolean downloadToTemp(String downloadUrl, String jarName) {
        try {
            File pluginsFolder = new File("plugins");
            if (!pluginsFolder.exists()) pluginsFolder.mkdirs();

            File temp = new File(pluginsFolder, jarName + ".new");
            if (temp.exists()) temp.delete();

            URL url = new URL(downloadUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestProperty("User-Agent", "BedWarsPlugin-Updater");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(15000);
            connection.connect();

            try (BufferedInputStream in = new BufferedInputStream(connection.getInputStream());
                 FileOutputStream out = new FileOutputStream(temp)) {
                byte[] buffer = new byte[4096];
                int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            }

            plugin.getLogger().info("Pobrano plik tymczasowy: " + temp.getName());
            return true;
        } catch (Exception e) {
            plugin.getLogger().warning("Błąd pobierania: " + e.getMessage());
            return false;
        }
    }

    private void notifyPlayersClickable(String latestVersion) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            TextComponent message = new TextComponent("✔ Nowa wersja BedWarsPlugin (" + latestVersion + ") dostępna! ");
            TextComponent click = new TextComponent("[Kliknij, aby zastosować]");
            click.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/bedwars update"));
            message.addExtra(click);
            player.spigot().sendMessage(message);
        }
    }

    public void applyUpdateWithPlugman() {
        if (lastDownloadedJarName == null) return;

        // Pobrany plik -> synchronizacja na główny wątek
        Bukkit.getScheduler().runTask(plugin, () -> {
            plugin.getLogger().info("Zastosowanie aktualizacji: " + lastDownloadedVersion);

            // 1. Wyłącz plugin przez PlugMan
            plugin.getServer().dispatchCommand(plugin.getServer().getConsoleSender(), "plugman disable BedWarsPlugin");

            // 2. Usuń stare wersje i zamień .new -> .jar
            File pluginsFolder = new File("plugins");
            File temp = new File(pluginsFolder, lastDownloadedJarName + ".new");
            if (!temp.exists()) {
                plugin.getLogger().warning("Plik tymczasowy nie istnieje: " + temp.getName());
                return;
            }

            File[] files = pluginsFolder.listFiles((dir, name) -> name.startsWith("BedWarsPlugin") && name.endsWith(".jar"));
            if (files != null) {
                for (File f : files) {
                    if (!f.getName().equals(temp.getName())) {
                        try { Files.deleteIfExists(f.toPath()); } catch (Exception ignored) {}
                    }
                }
            }

            File finalJar = new File(pluginsFolder, lastDownloadedJarName);
            try { Files.move(temp.toPath(), finalJar.toPath(), StandardCopyOption.REPLACE_EXISTING); } catch (Exception e) {
                plugin.getLogger().warning("Nie udało się przenieść pliku: " + e.getMessage());
                return;
            }

            // 3. Włącz plugin przez PlugMan
            plugin.getServer().dispatchCommand(plugin.getServer().getConsoleSender(), "plugman enable BedWarsPlugin");
            plugin.getLogger().info("Plugin włączony (PlugMan). Nowa wersja aktywna: " + lastDownloadedVersion);

            writeLocalVersion(lastDownloadedVersion);
        });
    }




    private String readLocalVersion() {
        try (BufferedReader reader = new BufferedReader(new FileReader(versionFile))) {
            return reader.readLine().trim();
        } catch (IOException e) {
            return plugin.getDescription().getVersion();
        }
    }

    private void writeLocalVersion(String version) {
        try (FileWriter writer = new FileWriter(versionFile, false)) {
            writer.write(version);
        } catch (IOException e) {
            plugin.getLogger().warning("Nie udało się zapisać wersji: " + e.getMessage());
        }
    }
}
