package org.BedWars;

import java.util.HashMap;
import java.util.Map;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class GeneratorDruzyny {
    private final BedWarsPlugin plugin;
    private final Map<String, Location> teamGeneratorLocations = new HashMap<>();
    private final int ironCooldown = 100;
    private final int goldCooldown = 200;
    private final Map<String, Integer> ironCounters = new HashMap<>();
    private final Map<String, Integer> goldCounters = new HashMap<>();

    private BukkitTask task; // <- tutaj przechowujemy task

    public GeneratorDruzyny(BedWarsPlugin plugin) {
        this.plugin = plugin;
    }

    public void setGenerator(String teamId, Location loc) {
        this.teamGeneratorLocations.put(teamId, loc);
        this.ironCounters.put(teamId, 0);
        this.goldCounters.put(teamId, 0);
    }

    public void removeGenerator(String teamId) {
        this.teamGeneratorLocations.remove(teamId);
        this.ironCounters.remove(teamId);
        this.goldCounters.remove(teamId);
    }

    public void start() {
        // zapisujemy task w polu
        this.task = new BukkitRunnable() {
            public void run() {
                for (Map.Entry<String, Location> entry : teamGeneratorLocations.entrySet()) {
                    String teamId = entry.getKey();
                    Location loc = entry.getValue();

                    int iron = ironCounters.getOrDefault(teamId, 0) + 1;
                    if (iron >= ironCooldown) {
                        loc.getWorld().dropItemNaturally(loc.clone().add(0.5, 1, 0.5), new ItemStack(Material.IRON_INGOT, 1));
                        iron = 0;
                    }
                    ironCounters.put(teamId, iron);

                    int gold = goldCounters.getOrDefault(teamId, 0) + 1;
                    if (gold >= goldCooldown) {
                        loc.getWorld().dropItemNaturally(loc.clone().add(0.5, 1, 0.5), new ItemStack(Material.GOLD_INGOT, 1));
                        gold = 0;
                    }
                    goldCounters.put(teamId, gold);
                }
            }
        }.runTaskTimer(this.plugin, 0L, 1L);
    }

    // nowa metoda stop
    public void stop() {
        if (this.task != null) {
            this.task.cancel();
            this.task = null;
        }
    }
}
